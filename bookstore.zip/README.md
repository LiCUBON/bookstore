# BookStore

1. Import the bookstore database into phpMyAdmin. Path: **"bookstore/sql/bookstore.sql"**
2. The database connection settings are located in **"/bookstore/inc/conectDB.php".**
